<?php
// =============================================
//  download.php — Download Notes
// =============================================
session_start();
require_once 'config.php';
requireLogin();

// Handle file download request
if (isset($_GET['file'])) {
    $requested = basename($_GET['file']);
    $filepath  = __DIR__ . '/notes/' . $requested;

    if (file_exists($filepath) && is_file($filepath)) {
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $requested . '"');
        header('Content-Length: ' . filesize($filepath));
        header('Cache-Control: no-cache');
        readfile($filepath);
        exit();
    } else {
        $error = 'File not found.';
    }
}

// List notes
$notes = [];
$notesDir = __DIR__ . '/notes/';
if (is_dir($notesDir)) {
    foreach (glob($notesDir . '*') as $file) {
        if (is_file($file)) {
            $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
            $icon = match($ext) {
                'pdf'  => '📕',
                'doc','docx' => '📘',
                'ppt','pptx' => '📙',
                'xls','xlsx' => '📗',
                'txt'  => '📄',
                default => '📁',
            };
            $notes[] = [
                'name' => basename($file),
                'size' => round(filesize($file)/1024, 1) . ' KB',
                'date' => date('d M Y', filemtime($file)),
                'ext'  => strtoupper($ext),
                'icon' => $icon,
            ];
        }
    }
}

// Fake demo notes if folder is empty
if (empty($notes)) {
    $demo = [
        ['PHP Basics - Chapter 1.pdf',      '215 KB', '01 Apr 2026', 'PDF', '📕'],
        ['Database Concepts.pdf',            '340 KB', '05 Apr 2026', 'PDF', '📕'],
        ['HTML & CSS Notes.docx',            '128 KB', '10 Apr 2026', 'DOCX','📘'],
        ['Data Structures.pdf',              '520 KB', '15 Apr 2026', 'PDF', '📕'],
        ['Operating Systems Notes.pptx',    '780 KB', '20 Apr 2026', 'PPTX','📙'],
    ];
    foreach ($demo as $d) {
        $notes[] = ['name'=>$d[0],'size'=>$d[1],'date'=>$d[2],'ext'=>$d[3],'icon'=>$d[4]];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Download Notes — Smart Student Portal</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .notes-wrap { max-width: 800px; margin: 0 auto; padding: 30px 24px 60px; }
        .search-box {
            position: relative;
            margin-bottom: 28px;
        }
        .search-box input {
            width: 100%;
            background: var(--glass);
            border: 1px solid var(--glass-border);
            border-radius: 50px;
            padding: 14px 20px 14px 48px;
            font-family: 'Outfit', sans-serif;
            font-size: 0.95rem;
            color: var(--text-light);
            outline: none;
            transition: var(--transition);
            backdrop-filter: blur(10px);
        }
        .search-box input:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 4px rgba(108,99,255,0.15);
        }
        .search-box input::placeholder { color: rgba(255,255,255,0.3); }
        .search-icon {
            position: absolute;
            left: 18px; top: 50%;
            transform: translateY(-50%);
            font-size: 1.1rem;
            opacity: 0.5;
        }

        .notes-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(340px, 1fr));
            gap: 16px;
        }

        .note-card {
            background: var(--glass);
            border: 1px solid var(--glass-border);
            border-radius: 16px;
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 16px;
            transition: var(--transition);
            position: relative;
            overflow: hidden;
        }

        .note-card::before {
            content: '';
            position: absolute;
            left: 0; top: 0; bottom: 0;
            width: 4px;
            background: linear-gradient(180deg, var(--primary), var(--secondary));
            transform: scaleY(0);
            transition: transform 0.3s ease;
            transform-origin: bottom;
        }

        .note-card:hover {
            transform: translateY(-4px);
            background: var(--glass-hover);
            border-color: rgba(255,255,255,0.25);
            box-shadow: 0 12px 40px rgba(0,0,0,0.3);
        }

        .note-card:hover::before { transform: scaleY(1); }

        .note-icon {
            width: 52px; height: 52px;
            border-radius: 14px;
            background: var(--glass);
            display: grid;
            place-items: center;
            font-size: 1.6rem;
            flex-shrink: 0;
        }

        .note-info { flex: 1; min-width: 0; }
        .note-name {
            font-size: 0.9rem;
            font-weight: 600;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            margin-bottom: 4px;
        }
        .note-meta { font-size: 0.75rem; color: var(--text-muted); }

        .download-btn {
            width: 38px; height: 38px;
            border-radius: 10px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            display: grid;
            place-items: center;
            color: #fff;
            text-decoration: none;
            font-size: 1rem;
            flex-shrink: 0;
            transition: var(--transition);
            box-shadow: 0 4px 12px rgba(108,99,255,0.3);
        }

        .download-btn:hover {
            transform: scale(1.1) rotate(-5deg);
            box-shadow: 0 6px 20px rgba(108,99,255,0.5);
        }

        .ext-badge {
            font-size: 0.65rem;
            font-weight: 700;
            letter-spacing: 0.5px;
            padding: 2px 7px;
            border-radius: 50px;
            margin-left: 6px;
        }

        .ext-PDF  { background: rgba(255,65,108,0.15); color: #ff8fab; }
        .ext-DOCX,.ext-DOC { background: rgba(108,99,255,0.15); color: #a89ec9; }
        .ext-PPTX,.ext-PPT { background: rgba(250,139,12,0.15); color: #fa8b0c; }
        .ext-XLSX,.ext-XLS { background: rgba(67,233,123,0.15); color: #43e97b; }
    </style>
</head>
<body>
<?php include 'includes/navbar.php'; ?>

<div class="page-wrapper">
    <div class="page-title">
        <h1>📥 Download <span class="gradient-text" style="background:linear-gradient(135deg,#0dd3bb,#6c63ff);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;">Study Notes</span></h1>
        <p><?= count($notes) ?> file<?= count($notes) !== 1 ? 's' : '' ?> available &nbsp;·&nbsp; Click the download button to save</p>
    </div>

    <div class="notes-wrap">
        <?php if (!empty($error)): ?>
            <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <!-- Search -->
        <div class="search-box fade-up">
            <span class="search-icon">🔍</span>
            <input type="text" id="searchInput" placeholder="Search notes by name…">
        </div>

        <!-- Notes Grid -->
        <div class="notes-grid" id="notesGrid">
            <?php foreach ($notes as $i => $note): ?>
                <div class="note-card reveal" data-name="<?= strtolower(htmlspecialchars($note['name'])) ?>"
                     style="transition-delay:<?= $i * 0.05 ?>s;">
                    <div class="note-icon"><?= $note['icon'] ?></div>
                    <div class="note-info">
                        <div class="note-name" title="<?= htmlspecialchars($note['name']) ?>">
                            <?= htmlspecialchars($note['name']) ?>
                            <span class="ext-badge ext-<?= $note['ext'] ?>"><?= $note['ext'] ?></span>
                        </div>
                        <div class="note-meta">
                            💾 <?= $note['size'] ?> &nbsp;·&nbsp; 📅 <?= $note['date'] ?>
                        </div>
                    </div>
                    <a href="download.php?file=<?= urlencode($note['name']) ?>"
                       class="download-btn" title="Download <?= htmlspecialchars($note['name']) ?>">
                        ⬇️
                    </a>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Empty state -->
        <div id="emptySearch" style="display:none; text-align:center; padding: 40px;">
            <div style="font-size:3rem;margin-bottom:12px;">🔍</div>
            <p style="color:var(--text-muted);">No notes found matching your search.</p>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
<script>
const searchInput = document.getElementById('searchInput');
const cards = document.querySelectorAll('.note-card');
const emptyMsg = document.getElementById('emptySearch');

searchInput.addEventListener('input', () => {
    const q = searchInput.value.toLowerCase().trim();
    let visible = 0;
    cards.forEach(card => {
        const name = card.dataset.name;
        const show = !q || name.includes(q);
        card.style.display = show ? '' : 'none';
        if (show) visible++;
    });
    emptyMsg.style.display = visible === 0 ? 'block' : 'none';
});
</script>
</body>
</html>
