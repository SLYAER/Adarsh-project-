<?php
// =============================================
//  login.php — Student Login
// =============================================
session_start();
require_once 'config.php';

if (isLoggedIn()) {
    header('Location: dashboard.php');
    exit();
}

$error = '';
$msg   = htmlspecialchars($_GET['msg'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!$username || !$password) {
        $error = 'Please fill in both fields.';
    } else {
        $stmt = $conn->prepare("SELECT id, username, full_name, course, password FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id']   = $user['id'];
                $_SESSION['username']  = $user['username'];
                $_SESSION['full_name'] = $user['full_name'];
                $_SESSION['course']    = $user['course'];
                header('Location: dashboard.php');
                exit();
            } else {
                $error = 'Incorrect password. Please try again.';
            }
        } else {
            $error = 'No account found with that username.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login — Smart Student Portal</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .shake { animation: shake 0.4s ease; }
        @keyframes shake {
            0%,100% { transform: translateX(0); }
            20%,60% { transform: translateX(-8px); }
            40%,80% { transform: translateX(8px); }
        }
        .show-pw {
            position: absolute;
            right: 14px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            font-size: 1rem;
            opacity: 0.5;
            transition: opacity 0.2s;
            user-select: none;
        }
        .show-pw:hover { opacity: 1; }
        .pw-wrapper { position: relative; }
        .pw-wrapper input { padding-right: 42px !important; }
    </style>
</head>
<body>
<?php include 'includes/navbar.php'; ?>

<div class="page-wrapper">
    <div class="form-container">
        <div class="form-box fade-up" id="loginBox">
            <div class="form-header">
                <div class="icon">🔑</div>
                <h2>Welcome Back</h2>
                <p>Log in to your student account</p>
            </div>

            <?php if ($msg): ?>
                <div class="alert alert-info">ℹ️ <?= $msg ?></div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="alert alert-error">⚠️ <?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <form method="POST" id="loginForm">
                <div class="form-group">
                    <label>Username</label>
                    <input type="text" name="username" placeholder="your_username"
                           value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
                           autofocus required>
                </div>

                <div class="form-group">
                    <label>Password</label>
                    <div class="pw-wrapper">
                        <input type="password" name="password" id="pwInput"
                               placeholder="Your password" required>
                        <span class="show-pw" id="togglePw" onclick="togglePassword()">👁️</span>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary btn-full" style="margin-top: 8px;">
                    Login →
                </button>
            </form>

            <div class="divider"></div>

            <!-- Demo hint -->
            <div class="alert alert-info" style="font-size:0.82rem; text-align:center;">
                💡 Don't have an account?
                <a href="register.php" style="color:var(--primary); font-weight:600;">Register first</a>
            </div>

            <div class="form-footer">
                <a href="index.php">← Back to Home</a>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>

<script>
function togglePassword() {
    const input = document.getElementById('pwInput');
    const btn   = document.getElementById('togglePw');
    if (input.type === 'password') {
        input.type = 'text';
        btn.textContent = '🙈';
    } else {
        input.type = 'password';
        btn.textContent = '👁️';
    }
}

<?php if ($error): ?>
// Shake animation on error
document.getElementById('loginBox').classList.add('shake');
setTimeout(() => document.getElementById('loginBox').classList.remove('shake'), 500);
<?php endif; ?>
</script>
</body>
</html>
